NESTED — GITHUB PAGES WEBSITE
============================

CONTENTS
- index.html: customer-facing website
- styles.css: responsive design
- thank-you.html: retained from the earlier package; not used by the current email-interest link
- assets/: Nested logo and product concept images

PUBLISH FOR FREE WITH GITHUB PAGES
1. Sign in at https://github.com/ and create a repository named nested-website.
2. Set the repository to Public.
3. Unzip this download. Open the inner Nested_GitHub_Pages folder.
4. Upload the CONTENTS of that folder to the top level (root) of the repository. The root should contain index.html, styles.css, thank-you.html, and assets/.
5. In the repository, open Settings > Pages.
6. Under Build and deployment, choose “Deploy from a branch”, select branch “main” and folder “/(root)”, then Save.
7. Wait for the Pages URL to appear in Settings > Pages. Open it and test the site on desktop and mobile.

CUSTOMER INTEREST / PREORDERS — IMPORTANT
- The current call to action opens the visitor's email app with a prefilled message to nestedgroup.official@gmail.com.
- This is NOT an online submission form. It will only work if the visitor has an email app or handler configured and chooses to send the message.
- GitHub Pages is static hosting and does not process form submissions by itself. To collect entries in a web form, connect an external form provider (for example, Formspree or Google Forms), configure its endpoint, and submit test entries before advertising it as working.
- No payment or checkout is configured. Do not take paid preorders until pricing, production readiness, estimated fulfillment, cancellation/refund terms, and payment processing are decided and clearly disclosed.
- The website describes the product as a concept in development; product photos are concept images and should not be presented as proof of a finished, available product.

STILL NEEDED
- Parent survey URL (not provided yet). Add it to the survey section when ready.
- If you want an actual web form, choose and configure a form provider; test submissions and notifications.
- If you intend to accept money, choose and configure a payment provider only after preorder terms are established.
- Add a privacy notice explaining what customer information is collected, how it is used, and how people can request deletion. Avoid collecting children's names or contact details.
- Verify current GitHub Pages terms and limits at https://docs.github.com/en/pages.

CONTACT
nestedgroup.official@gmail.com
